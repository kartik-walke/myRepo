# Hello, Welcome to Day 3

'''

# Day3 (Basic Operators)
- arithematic operations
- **, %
- Concating Strings
- add Two Lists (+)
- multiply(*) with list
- print multiple strings "%(,,),+"
- (+) preffered

'''

# Arithematic Operations

x = 4
y = 5

add = x+y
sub = x-y
multi = x*y
div = x/y
power = x**y
quotient = x//y

# Expressions
number = 1 + 2 * 3 / 4.0
print(number)

# concating strings
fName = "Kartik"
lName = "Walke"

print("Hi guys, my name is"+fName+lName) # Wrong
print("Hi guys, my name is " + fName + " " + lName) # Correct
print("Hi guys, my name is %s %s" %(fName, lName)) # Correct

nums1 = [1,2,7,8]
nums2 = [3,4,5,6]

nums = nums1 + nums2
print(nums)
print(nums * 2)


'''

Time to assess your learning 😎

1) X = [3,6,9,12]. Iterate over all the list elements and divide them by 3 and print every operation

input = [3,6,9,12]
output = 1
         2
         3
         4

2) X = [3,6,9,12]. Iterate over all the list elements and print square of each element.

input = [3,6,9,12]
Output = 9
        36
        81
        144

'''