# Good Morning!
# Welcome to Day-2
# I hope you've completed exercise for Day-1

'''
Let's look at today's agenda

# Day2 (Lists Introduction)
- list (array in other lang)
- list operations
  - append() // Add Elements to last
  - printing elements
  - traversing list
  - indexOutOfBound Exception
'''


# List Introduction
x = list()
y = []

# append()
x.append(1)
x.append(31)
x.append(54)
x.append(77)

y.append("Kartik")
y.append("Walke")

# Accessing List
print(x[1])
print(y[0])

# Traversing List
# for in
for k in x:
    print(k)

# for range
for i in range(len(x)):
    print(x[i])

# indexOutOfBound Exception
print(x[6])


'''
Exercise Time 😃

1) Perform following operations with list
  i) Create a list with 
     X = [2,5,7,3,6,8,9]
  ii) add element 35 to X
  iii) add element 23 to X
  iv) Traverse X and print only the last element (looks Tricky 🤔).
  v) Find sum of all list elements and display the sum using sum variable.

Happy Learning 😁

'''