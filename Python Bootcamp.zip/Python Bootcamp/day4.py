# Hello, Welcome to Day 4

'''

# Day4 (Playing with Strings)
- String Operations
  - index() // get index of specific element
  - count() // get count of a char in string
  - Slicing // Both Positive and Negative
  - Jumping Condition
  - Reverse with [::-1]
  - upper() and lower()
  - len()
  - startswith(), endswith()
  - split(delimiter)

looks so much 🙄. But, just be with me. 
It's not that hard at all.

'''

X = "Kartik Walke"

# index 
print(X.index('i'))

# count 
print(X.count('k'))

# Slicing
print(X[1:4])
print(X[5:])
print(X[:3])
print(X[-4:])
print(X[:-3])

# Jumping with slicing
print(X[1:6:2])
print(X[::2])
print(X[::3])
print(X[::-1]) # Hack 😉

# upper() and lower()
print(X.upper())
print(X.lower())
print(X[:-3].lower())

# len()
print(len(X))

# startswith() and endswith()
print(X.startswith('k'))
print(X.endswith('e'))
print(X.startswith(''))

# split() ***imp
print(X.split(' '))
Y = "Ram-Sham-Ganesh-Sona"
# How to split this now 🤔
# print(Y.split())

'''

look I told you it's easy and it's done now 😉

Now, Exercise Time 😂.

There's no specific question for this day.
Have Fun and Enjoy !! 😉. (No Homework Day)

But once again go through all this string operations.
As these are important functions with respect to Strings

'''