# Hey Guys, Welcome to Day6

'''

Let's discuss about today's agenda

# Day6 (looping and oops)
- while loop (Same as C)
- break and continue
- functions
- class (self)
- constructor (__init__())

'''

# While Loop

# Fact - There are no increment decrement operators in Python
x = 0

while(x < 50):
    print(x, end=" ")
    x+=1
    # x = x+1

# break and continue
y = 0
while(y < 10):
    if(y==4):
        break
    print(y, end=" ")
    y+=1

z = 0
while(z < 7):
    if(z == 5):
        z+=1
        continue
    print(z, end=" ")
    z+=1

# functions
def add(x,y):
    return x+y
print(45,54)

# class, constructor
class Operations:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def sum(self):
        return self.x+self.y

ok = Operations(5,6)
print(ok.sum())

'''

Assignment Time
1) Print first 10 prime numbers using while loop (Tricky)
2) X = 7 print factorial of 7 using while loop. (7*6*5*4*3*2*1)
3) Complete above class Operations and add substraction(), multiplication() and division() to it.

'''