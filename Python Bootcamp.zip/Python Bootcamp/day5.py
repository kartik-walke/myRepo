# Hello, Welcome to Day 5

'''

# Day5 (conditional statement and looping)
- Conditional Operators (returns boolean values)
  - == (Equals to)
  - <,>,<=,>= (Greater than,less than)
  - in (list, string)
  - and,or,not
- for loop (for in, for range)
  - in (iterables)
  - range (,,)

'''

# Conditonal Operators
print(29>35)
print(29>=35)
print(29<35)
print(29<=35)
print(29==35)

# in
X = [4,7,35,75,34]
Y = "Kartik"
print(45 in X)
print(4 in X)

# print(4 in 45) 
# in requires 2nd parameter as a iterable

print('k' in Y)

# and, or, not
print((9>5)and(4<9))
print((9>5)and not(4<9))
print((9>5)or not(4<9))

# for loop

# for(int i=0; i<5; i++) not used here

for i in range(5): # works same in python
    print(i,end=" ")

# range() => (firstIndex, lastIndex, Jumping)

for i in range(1,50,4):
    print(i,end=" ")

'''

Let's find out do you really study previous day's string operations

1) Tell me any 3 string function and their uses.
2) [5:10:2] will print??
3) Kartik-Walke how to extract name by eliminating '-'

It's a good habit to recall the previous day's work and
today's concepts in order to make all of the learning interesting and fun!!!
'''



'''
Time For HomeWork Questions:
1) Print all odd numbers from 1 to 100 using for loop.
(Hint: Use Jumping)

2) Print all prime numbers from 1 to 100 using for loop.

3) X = [2,4,6,8,9]. Append the following elements in list 
"IF THEY'RE NOT PRESENT IN THE LIST".
    3,5,4,8,7,5

4) X = [1,2,3,4,5,6,7,8,9,100] Print all the elements which are
   i) Divisible by 3
   ii) Divisible by 3 and 5 (Use Conditional Operators + Arithematic Operators)
   iii) are prime numbers
   iv) greater than 5

'''