# Hello Everyone, Welcome to 10 Days Python Bootcamp
# My Name is Kartik Walke

'''

Let's look at what we're going to learn today

# Day1 (Basics Datatypes)
- Print()
- Indentation
- Variables & Datatypes
- type
- datatype operations

'''


# Print
print("Hello World!")

#variables
x = 1
y = 2

# Indentation
# ":"
if(x==y):
    print("They are same!!!")
else:
    print("They are not same!!!")
    
#type
print(type(x))
print(type(3.5))
print(type("Kartik"))

#operations
z = x+y
print(z)

fName = "Kartik"
lName = "Walke"
print(fName+lName)

'''

Learning is incomplete without Practise :)
                            - Kartik Walke

1) check type() of each datatype in python (int, float, boolean, str)
2) take variable x = 99 & print if it's even or odd using if else
3) take three variables rollNo, firstName and lastName, initialize them with your rollNo 
firstName and lastName. Print the following line using print()

Hello Guys, My Name is 'Kartik Walke' and my roll number is CS4168.

Happy Learning !!!

Recommended website to explore more - https://www.learnpython.org (You can go with others too..)

'''