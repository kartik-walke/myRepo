'''

Welcome to Day7 guys

# Day7 (Tuple, Dictionary)
- Dictionary
- Iterating over
- add, del
- Tuple
- Operations

'''

# Dictionary, Iteration
dic = dict()
dic["Kartik"] = "Walke";
dic["Ram"] = "Sharma";

for [i,e] in dic.items():
    print(e,i)

for i in dic.keys():
    print(i)

del dic["Kartik"]

for i in dic.values():
    print(i)

#Tuple
X = (5,7,9,1)
# we can't add any other element here
for i in X:
    print(i)

'''

By this, we have come towards end of the basic course of python.
Tommorow, I'll share some imp techniques using python for coding


Assignment Time 
1) create a dictionary with yourInfo. It should contain fName, lName, address, mobile, pincode.
By using the dictionary print a following line using function

(take dictionary as a parameter of function)

Hello, My Name is Kartik Walke. I currently live at BajajNagar, Aurangabad-431136. My Mobile Number is 9999912345. 


2) Create a tuple daysInWeek = ["Monday".."Saturday"]
X = 1. Now take Monday as 0th day and print 1st day in week

'''